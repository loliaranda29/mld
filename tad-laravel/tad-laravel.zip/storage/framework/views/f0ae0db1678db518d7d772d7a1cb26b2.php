<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title', 'Mi Luján Digital'); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  
  <style>[x-cloak]{ display:none !important; }</style>

  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  
  <link href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css" rel="stylesheet">

  
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/footer.css')); ?>">

  
  <script defer
          src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"
          onerror="
            var s=document.createElement('script');
            s.defer=true;
            s.src='https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js';
            document.head.appendChild(s);
          ">
  </script>
  <script>
    // Aviso en consola si Alpine no cargó
    window.addEventListener('DOMContentLoaded', function () {
      setTimeout(function () {
        if (!window.Alpine) {
          console.error('Alpine.js no se cargó. Verificá que el CDN no esté bloqueado por la red.');
        }
      }, 0);
    });
  </script>

  <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
  <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Major\mld\tad-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>