<?php

use Illuminate\Support\Facades\Route;

Route::get('/admin/test-tramites', function () {
    return 'Ruta de superadmin_tramites funcionando';
});
