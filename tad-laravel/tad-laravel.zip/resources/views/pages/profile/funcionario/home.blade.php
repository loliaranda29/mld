@extends('layouts.app-funcionario')

@section('title', 'Inicio Funcionario')

@section('profile_content')
  <h1 class="text-xl font-bold mb-4">Bienvenido funcionario</h1>

 
@endsection




