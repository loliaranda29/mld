@extends('layouts.app-funcionario')

@section('title', 'Inicio Funcionario')

@section('content')
  <h1 class="text-xl font-bold">Bienvenido funcionario</h1>
@endsection
