


<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h4 class="mb-3"><?php echo e($solicitud->tramite->nombre); ?></h4>
  <div class="text-muted mb-3">
    Expediente: <strong><?php echo e($solicitud->expediente); ?></strong>
    — Estado: <span class="badge bg-secondary text-uppercase"><?php echo e($solicitud->estado); ?></span>
  </div>

  <?php
    $tramite  = $solicitud->tramite ?? null;
    $sections = is_array($schema) ? ($schema['sections'] ?? []) : [];

    // === Helpers usados más abajo ===

    // Normaliza el valor del campo según su tipo
    $fieldValue = function (array $f) {
        $v    = $f['value'] ?? null;
        $type = strtolower($f['type'] ?? 'text');

        // checkbox múltiple -> siempre array
        if ($type === 'checkbox' && !empty($f['multiple'])) {
            return is_array($v) ? $v : ($v ? [$v] : []);
        }
        return $v;
    };

    // Imprime "—" si viene vacío / null / array vacío
    $printDash = function ($v) {
        if (is_array($v)) {
            return count($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : '—';
        }
        if ($v === null || $v === '') {
            return '—';
        }
        return (string) $v;
    };
  ?>

  <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-3">
      <div class="card-header bg-primary text-white fw-semibold">
        <?php echo e($sec['name'] ?? 'Sección'); ?>

      </div>
      <div class="card-body">
        <?php $__empty_2 = true; $__currentLoopData = ($sec['fields'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
          <?php
            $label = $f['label'] ?? $f['name'] ?? 'Campo';
            $type  = strtolower($f['type'] ?? 'text');
            $val   = $fieldValue($f);
          ?>

          <div class="mb-3">
            <div class="text-muted small"><?php echo e($label); ?></div>

            <?php if($type === 'file'): ?>
              <?php
                $files = is_array($val) ? $val : ($val ? [$val] : []);
              ?>

              <?php if(count($files)): ?>
                <ul class="list-unstyled mb-0">
                  <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ix => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $url  = $file['url']  ?? null;
                      $name = $file['name'] ?? ('Archivo '.($ix+1));
                    ?>
                    <li>
                      <?php if($url): ?>
                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener"><?php echo e($name); ?></a>
                      <?php else: ?>
                        <?php echo e($name); ?>

                      <?php endif; ?>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              <?php else: ?>
                <div>—</div>
              <?php endif; ?>

            <?php else: ?>
              <div><?php echo e($printDash(is_array($val) ? json_encode($val, JSON_UNESCAPED_UNICODE) : $val)); ?></div>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
          <div class="text-muted">—</div>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-warning">Este trámite no tiene secciones configuradas.</div>
  <?php endif; ?>

  <div class="mt-3">
    <a href="<?php echo e(route('profile.solicitudes.index')); ?>" class="btn btn-outline-secondary">Volver a mis trámites</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Major\mld\tad-laravel\resources\views/pages/profile/ciudadano/solicitudes/show.blade.php ENDPATH**/ ?>