{{-- resources/views/pages/profile/ciudadano/solicitud_show.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container py-4">
  <h4 class="mb-3">{{ $solicitud->tramite->nombre }}</h4>
  <div class="text-muted mb-3">
    Expediente: <strong>{{ $solicitud->expediente }}</strong>
    — Estado: <span class="badge bg-secondary text-uppercase">{{ $solicitud->estado }}</span>
  </div>

  @php
    $tramite  = $solicitud->tramite ?? null;
    $sections = is_array($schema) ? ($schema['sections'] ?? []) : [];

    // === Helpers usados más abajo ===

    // Normaliza el valor del campo según su tipo
    $fieldValue = function (array $f) {
        $v    = $f['value'] ?? null;
        $type = strtolower($f['type'] ?? 'text');

        // checkbox múltiple -> siempre array
        if ($type === 'checkbox' && !empty($f['multiple'])) {
            return is_array($v) ? $v : ($v ? [$v] : []);
        }
        return $v;
    };

    // Imprime "—" si viene vacío / null / array vacío
    $printDash = function ($v) {
        if (is_array($v)) {
            return count($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : '—';
        }
        if ($v === null || $v === '') {
            return '—';
        }
        return (string) $v;
    };
  @endphp

  @forelse($sections as $sec)
    <div class="card mb-3">
      <div class="card-header bg-primary text-white fw-semibold">
        {{ $sec['name'] ?? 'Sección' }}
      </div>
      <div class="card-body">
        @forelse(($sec['fields'] ?? []) as $f)
          @php
            $label = $f['label'] ?? $f['name'] ?? 'Campo';
            $type  = strtolower($f['type'] ?? 'text');
            $val   = $fieldValue($f);
          @endphp

          <div class="mb-3">
            <div class="text-muted small">{{ $label }}</div>

            @if($type === 'file')
              @php
                $files = is_array($val) ? $val : ($val ? [$val] : []);
              @endphp

              @if(count($files))
                <ul class="list-unstyled mb-0">
                  @foreach($files as $ix => $file)
                    @php
                      $url  = $file['url']  ?? null;
                      $name = $file['name'] ?? ('Archivo '.($ix+1));
                    @endphp
                    <li>
                      @if($url)
                        <a href="{{ $url }}" target="_blank" rel="noopener">{{ $name }}</a>
                      @else
                        {{ $name }}
                      @endif
                    </li>
                  @endforeach
                </ul>
              @else
                <div>—</div>
              @endif

            @else
              <div>{{ $printDash(is_array($val) ? json_encode($val, JSON_UNESCAPED_UNICODE) : $val) }}</div>
            @endif
          </div>
        @empty
          <div class="text-muted">—</div>
        @endforelse
      </div>
    </div>
  @empty
    <div class="alert alert-warning">Este trámite no tiene secciones configuradas.</div>
  @endforelse

  <div class="mt-3">
    <a href="{{ route('profile.solicitudes.index') }}" class="btn btn-outline-secondary">Volver a mis trámites</a>
  </div>
</div>
@endsection
