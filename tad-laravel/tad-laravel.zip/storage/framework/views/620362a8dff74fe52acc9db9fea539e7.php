

<?php $__env->startSection('content'); ?>
<?php
  // vienen del controlador: $solicitud y $schema
  $tramite  = $solicitud->tramite ?? null;
  $sections = is_array($schema) ? ($schema['sections'] ?? []) : [];
?>


<div class="container py-4"
     x-data="wizardForm(<?php echo \Illuminate\Support\Js::from($sections)->toHtml() ?>)"
     x-init="init()"
>
    <div class="row">
        <div class="col-12 col-lg-10 mx-auto">
            <h3 class="mb-3"><?php echo e($tramite->nombre ?? 'Nuevo trámite'); ?></h3>

<input type="hidden" name="tramite_id"
       value="<?php echo e($tramite->id ?? $solicitud->tramite_id); ?>">


            <form method="POST"
                  action="<?php echo e(route('profile.solicitudes.store')); ?>"
                  enctype="multipart/form-data"
                  x-on:submit.prevent="beforeSubmit($event)"
            >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tramite_id" value="<?php echo e($tramite->id); ?>">
                <input type="hidden" x-ref="answersJson" name="answers_json" value="{}">

                
                <div class="mb-3">
                    <div class="progress">
                        <div class="progress-bar" role="progressbar"
                             :style="`width:${progress()}%`"
                             :aria-valuenow="stepIndex+1"
                             aria-valuemin="1"
                             :aria-valuemax="sections.length">
                            <span x-text="`Paso ${stepIndex+1} de ${sections.length}`"></span>
                        </div>
                    </div>
                </div>

                
                <template x-if="currentSection()">
                    <div class="card shadow-sm mb-3">
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <strong x-text="currentSection().name || `Sección ${stepIndex+1}`"></strong>
                            <span class="badge bg-secondary" x-text="`Sección ${stepIndex+1}`"></span>
                        </div>
                        <div class="card-body">
                            <template x-for="(field, idx) in (currentSection().fields || [])" :key="idx">
                                <div class="mb-3" x-show="isFieldVisible(field)">
                                    <label class="form-label d-block">
                                        <span x-text="field.label || field.name"></span>
                                        <span x-show="field.required" class="text-danger">*</span>
                                    </label>

                                    
                                    <template x-if="['text','search','code','richtext'].includes((field.type||'text').toLowerCase())">
                                        <input type="text"
                                               class="form-control"
                                               :name="`form[${field.name}]`"
                                               :placeholder="field.placeholder || ''"
                                               x-model="model[field.name]">
                                    </template>

                                    <template x-if="(field.type||'')==='textarea'">
                                        <textarea class="form-control"
                                                  rows="4"
                                                  :name="`form[${field.name}]`"
                                                  x-model="model[field.name]"></textarea>
                                    </template>

                                    <template x-if="(field.type||'')==='number'">
                                        <input type="number"
                                               class="form-control"
                                               :name="`form[${field.name}]`"
                                               x-model="model[field.name]">
                                    </template>

                                    <template x-if="(field.type||'')==='date'">
                                        <input type="date"
                                               class="form-control"
                                               :name="`form[${field.name}]`"
                                               x-model="model[field.name]">
                                    </template>

                                    <template x-if="(field.type||'')==='select'">
                                        <select class="form-select"
                                                :name="`form[${field.name}]`"
                                                x-model="model[field.name]">
                                            <option value="" x-show="!field.required">-- Seleccionar --</option>
                                            <template x-for="(opt, i2) in (field.options || [])" :key="i2">
                                                <option
                                                    :value="(typeof opt==='object') ? (opt.value ?? opt.label ?? '') : opt"
                                                    x-text="(typeof opt==='object') ? (opt.label ?? opt.value ?? '') : opt">
                                                </option>
                                            </template>
                                        </select>
                                    </template>

                                    <template x-if="(field.type||'')==='checkbox' && !field.multiple">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                   :name="`form[${field.name}]`"
                                                   :value="1"
                                                   x-model="model[field.name]">
                                            <label class="form-check-label" x-text="field.help || 'Seleccionar'"></label>
                                        </div>
                                    </template>

                                    <template x-if="(field.type||'')==='checkbox' && field.multiple">
                                        <div class="d-flex flex-wrap gap-3">
                                            <template x-for="(opt, i3) in (field.options || [])" :key="i3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox"
                                                           :name="`form[${field.name}][]`"
                                                           :value="(typeof opt==='object') ? (opt.value ?? opt.label ?? '') : opt"
                                                           x-model="model[field.name]">
                                                    <label class="form-check-label"
                                                           x-text="(typeof opt==='object') ? (opt.label ?? opt.value ?? '') : opt"></label>
                                                </div>
                                            </template>
                                        </div>
                                    </template>

                                    
                                    <template x-if="(field.type||'')==='file' && !field.multiple">
                                        <input type="file"
                                               class="form-control"
                                               :name="`files[${field.name}]`"
                                               x-on:change="onFileChange($event, field)">
                                    </template>

                                    <template x-if="(field.type||'')==='file' && field.multiple">
                                        <input type="file"
                                               multiple
                                               class="form-control"
                                               :name="`files[${field.name}][]`"
                                               x-on:change="onFileChange($event, field)">
                                    </template>

                                    
                                    <small class="text-muted" x-text="field.help || ''"></small>
                                </div>
                            </template>
                        </div>
                    </div>
                </template>

                
                <div class="d-flex justify-content-between">
                    <button type="button" class="btn btn-outline-secondary"
                            :disabled="stepIndex === 0"
                            @click="prevStep">
                        ← Anterior
                    </button>

                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-primary"
                                x-show="!isLastStep()"
                                :disabled="!canGoNext()"
                                @click="nextStep">
                            Siguiente →
                        </button>

                        <button type="submit" class="btn btn-success"
                                x-show="isLastStep()"
                                :disabled="!canSubmit()">
                            Enviar solicitud
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('wizardForm', (sections) => ({
        sections: sections || [],
        stepIndex: 0,
        model: {},

        init(){
            (this.sections || []).forEach(sec => {
                (sec.fields || []).forEach(f => {
                    const name = f.name || '';
                    if (!name) return;
                    if ((f.type||'') === 'checkbox' && f.multiple) {
                        this.model[name] = [];
                    } else if ((f.type||'') === 'checkbox') {
                        this.model[name] = false;
                    } else {
                        this.model[name] = '';
                    }
                });
            });
            this.syncJson();
        },

        currentSection(){ return (this.sections || [])[this.stepIndex] || null; },
        isLastStep(){ return this.stepIndex >= (this.sections.length - 1); },
        progress(){ if (!this.sections.length) return 0; return Math.round(((this.stepIndex + 1) / this.sections.length) * 100); },

        isFieldVisible(field){
            if (!field) return true;
            if ((!field.condition || field.condition === '') && (!field.conditions || Object.keys(field.conditions||{}).length===0)) {
                return true;
            }
            const dep = field.dependsOn || null;
            if (dep && Object.prototype.hasOwnProperty.call(this.model, dep)) {
                const val = this.model[dep];
                if (field.conditions && typeof field.conditions === 'object') {
                    return Object.prototype.hasOwnProperty.call(field.conditions, val);
                }
            }
            return true;
        },

        nextStep(){ if (this.stepIndex < this.sections.length - 1) { this.stepIndex++; this.syncJson(); } },
        prevStep(){ if (this.stepIndex > 0) { this.stepIndex--; this.syncJson(); } },

        canGoNext(){
            const sec = this.currentSection(); if (!sec) return false;
            for (const f of (sec.fields || [])) {
                if (!f || !f.required) continue;
                if (!this.isFieldVisible(f)) continue;
                const v = this.model[f.name];
                if ((f.type||'') === 'file') continue;
                if ((f.type||'') === 'checkbox' && f.multiple) {
                    if (!Array.isArray(v) || v.length === 0) return false;
                } else if (v === '' || v === null || v === false) {
                    return false;
                }
            }
            return true;
        },

        canSubmit(){ return this.canGoNext(); },

        onFileChange(e, field){
            if (field && field.name) {
                const files = e.target.files;
                this.model[field.name] = files && files.length ? '[archivo seleccionado]' : '';
                this.syncJson();
            }
        },

        syncJson(){
            try { if (this.$refs['answersJson']) this.$refs['answersJson'].value = JSON.stringify(this.model || {}); } catch (e) {}
        },

        beforeSubmit(e){
            if (!this.isLastStep()) { this.nextStep(); e.preventDefault(); return false; }
            this.$nextTick(() => { this.syncJson(); e.target.submit(); });
            return false;
        },
    }));
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Major\mld\tad-laravel\resources\views/pages/profile/ciudadano/details/solicitud.blade.php ENDPATH**/ ?>