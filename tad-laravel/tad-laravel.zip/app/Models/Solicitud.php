<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Solicitud extends Model
{
    protected $table = 'solicitudes';

    protected $fillable = [
        'tramite_id',
        'usuario_id',
        'expediente',
        'estado',
        'datos',
        // 'respuestas_json', // ← si tu tabla NO la tiene todavía, comentá o quitá esta línea
    ];

    protected $casts = [
        'datos'           => 'array',
        // 'respuestas_json' => 'array', // ← opcional: solo si la columna existe
    ];

    protected $attributes = [
        'estado' => 'iniciado',
        // 'respuestas_json' => '[]', // ← **QUITAR**: esto forzaba el INSERT de una columna inexistente
        // 'datos' => '[]',           // si usás SQL Server y preferís string JSON, podés dejarlo; si no, omitilo
    ];

    public function tramite() { return $this->belongsTo(\App\Models\Tramite::class, 'tramite_id'); }
    public function usuario() { return $this->belongsTo(\App\Models\Usuario::class, 'usuario_id'); }
}
