{{-- resources/views/pages/profile/ciudadano/details/solicitud.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container py-4">
  <h4 class="mb-3">{{ $solicitud->tramite->nombre }}</h4>
  <div class="text-muted mb-3">
    Expediente: <strong>{{ $solicitud->expediente }}</strong>
    — Estado: <span class="badge bg-secondary text-uppercase">{{ $solicitud->estado }}</span>
  </div>

@php
  $tramite  = $solicitud->tramite ?? null;
  $sections = is_array($schema) ? ($schema['sections'] ?? []) : [];

  // Helpers para mostrar valores
  $fieldValue = function (array $f) {
    // Soporta: value plano (viejo), o value estructurado (archivos)
    if (array_key_exists('value', $f)) {
        return $f['value'];
    }
    // fallback por si vinieran en otra clave (no usual)
    return $f['val'] ?? null;
  };

  $printDash = function ($v) {
    if ($v === null) return '—';
    $s = is_string($v) ? trim($v) : $v;
    if ($s === '' || $s === false) return '—';
    return $s;
  };
@endphp

  @forelse($sections as $sec)
    <div class="card mb-3">
      <div class="card-header bg-primary text-white fw-semibold">
        {{ $sec['name'] ?? 'Sección' }}
      </div>
      <div class="card-body">
        @forelse(($sec['fields'] ?? []) as $f)
          @php
            $label = $f['label'] ?? $f['name'] ?? 'Campo';
            $type  = strtolower($f['type'] ?? 'text');
            $val   = $fieldValue($f);
          @endphp

          <div class="mb-3">
            <div class="text-muted small">{{ $label }}</div>

            @if($type === 'file')
              @php
                $files = is_array($val) ? $val : ($val ? [$val] : []);
              @endphp

              @if(count($files))
                <ul class="list-unstyled mb-0">
                  @foreach($files as $ix => $file)
                    @php
                      $url  = is_array($file) ? ($file['url'] ?? null) : null;
                      $name = is_array($file) ? ($file['name'] ?? ('Archivo '.($ix+1))) : ('Archivo '.($ix+1));
                    @endphp
                    <li>
                      @if($url)
                        <a href="{{ $url }}" target="_blank" rel="noopener">{{ $name }}</a>
                      @else
                        {{ $name }}
                      @endif
                    </li>
                  @endforeach
                </ul>
              @else
                <div>—</div>
              @endif

            @else
              <div>{{ $printDash(is_array($val) ? json_encode($val, JSON_UNESCAPED_UNICODE) : $val) }}</div>
            @endif
          </div>
        @empty
          <div class="text-muted">—</div>
        @endforelse
      </div>
    </div>
  @empty
    <div class="alert alert-warning">Este trámite no tiene secciones configuradas.</div>
  @endforelse

  <div class="mt-3">
    <a href="{{ route('profile.solicitudes.index') }}" class="btn btn-outline-secondary">Volver a mis trámites</a>
  </div>
</div>
@endsection
