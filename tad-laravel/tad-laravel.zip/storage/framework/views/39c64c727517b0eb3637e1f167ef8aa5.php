<?php $__env->startSection('profile_content'); ?>
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 mb-0">Gestión de Trámites</h1>
    <a href="<?php echo e(route('funcionario.tramites.create')); ?>" class="btn btn-primary">
      + Nuevo trámite
    </a>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <div class="card">
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th>Nombre</th>
              <th>Padre</th>
              <th>Subtrámites</th>
              <th>Vínculos</th>
              <th>Estado</th>
              <th class="text-end">Acciones</th>
            </tr>
          </thead>
          <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $tramites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td>
                <strong><?php echo e($t->nombre); ?></strong>
                <?php if($t->descripcion): ?>
                  <div class="text-muted small"><?php echo e(Str::limit($t->descripcion, 80)); ?></div>
                <?php endif; ?>
              </td>
              <td class="text-muted">
                <?php echo e($t->parent?->nombre ?? '—'); ?>

              </td>
              <td>
                
                <?php echo e($t->hijos()->count()); ?>

              </td>
              <td>
                
                <?php echo e($t->relacionados()->count()); ?>

              </td>
              <td>
                <?php if($t->publicado): ?>
                  <span class="badge bg-success">Publicado</span>
                <?php else: ?>
                  <span class="badge bg-secondary">Borrador</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('funcionario.tramites.edit', $t->id)); ?>">Editar</a>

                <form action="<?php echo e(route('funcionario.tramites.destroy', $t->id)); ?>" method="POST" class="d-inline"
                      onsubmit="return confirm('¿Eliminar definitivamente este trámite?');">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-outline-danger">Eliminar</button>
                </form>
              </td>
            </tr>

            
            <?php $__currentLoopData = $t->hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="table-sm">
                <td>
                  <span class="text-muted">↳</span> <?php echo e($h->nombre); ?>

                </td>
                <td class="text-muted"><?php echo e($h->parent?->nombre ?? '—'); ?></td>
                <td><?php echo e($h->hijos()->count()); ?></td>
                <td><?php echo e($h->relacionados()->count()); ?></td>
                <td>
                  <?php if($h->publicado): ?>
                    <span class="badge bg-success">Publicado</span>
                  <?php else: ?>
                    <span class="badge bg-secondary">Borrador</span>
                  <?php endif; ?>
                </td>
                <td class="text-end">
                  <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('funcionario.tramites.edit', $h->id)); ?>">Editar</a>
                  <form action="<?php echo e(route('funcionario.tramites.destroy', $h->id)); ?>" method="POST" class="d-inline"
                        onsubmit="return confirm('¿Eliminar este subtrámite?');">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-outline-danger">Eliminar</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">No hay trámites aún.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-funcionario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Major\mld\tad-laravel\resources\views/pages/profile/funcionario/tramite_config.blade.php ENDPATH**/ ?>