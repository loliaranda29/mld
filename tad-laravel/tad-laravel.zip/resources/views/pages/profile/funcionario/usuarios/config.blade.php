@extends('layouts.app-funcionario')

@section('content')
<div class="container mt-5">
    <h1 class="mb-3">Configuración de Usuarios</h1>
    <p>Próximamente se podrá configurar permisos y más.</p>
</div>
@endsection
