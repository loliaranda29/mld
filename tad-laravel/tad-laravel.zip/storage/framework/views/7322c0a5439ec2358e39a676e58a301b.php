

<?php $__env->startSection('profile_content'); ?>
<div class="card shadow rounded-4 px-4 py-5 mb-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0 fw-semibold">Mis solicitudes</h5>
    
    <a href="<?php echo e(route('profile.catalogo')); ?>" class="btn btn-outline-secondary btn-sm">
      Nuevo trámite
    </a>
  </div>

  <form method="GET" action="" class="mb-4">
    <div class="input-group">
      <input type="text" name="search" class="form-control" placeholder="Buscar por expediente" value="<?php echo e(request('search')); ?>">
      <button class="btn btn-outline-secondary" type="submit">Buscar</button>
    </div>
  </form>

  <?php $__empty_1 = true; $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-3 border-0 shadow-sm rounded-4">
      <div class="card-body d-flex justify-content-between align-items-center">
        <div>
          <div class="small text-muted">Expediente</div>
          <div class="fw-bold"><?php echo e($s->expediente); ?></div>
          <div class="small mt-2">
            Trámite: <span class="fw-semibold"><?php echo e($s->tramite->nombre ?? '—'); ?></span>
          </div>
          <div class="small text-muted">Estado: <span class="badge bg-light text-dark"><?php echo e($s->estado); ?></span></div>
        </div>
        <a class="btn btn-primary" href="<?php echo e(route('profile.solicitudes.show', $s->id)); ?>">Abrir</a>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-info mb-0">Aún no tenés solicitudes creadas.</div>
  <?php endif; ?>

  <div class="mt-3">
    <?php echo e($solicitudes->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Major\mld\tad-laravel\resources\views/pages/profile/ciudadano/solicitudes.blade.php ENDPATH**/ ?>