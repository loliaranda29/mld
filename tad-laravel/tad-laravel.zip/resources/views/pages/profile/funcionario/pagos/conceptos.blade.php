@extends('layouts.app-funcionario')
@section('title','Catálogo de conceptos')
@section('profile_content')
<div class="container mt-4">
  <div class="alert alert-secondary">Placeholder de Catálogo de conceptos. Luego lo llenamos.</div>
</div>
@endsection
